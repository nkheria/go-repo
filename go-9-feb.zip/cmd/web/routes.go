package main

import (
	"net/http"

	"example.com/go-demo-1/pkg/config"
	"example.com/go-demo-1/pkg/handlers"
	"github.com/bmizerany/pat"
)

func routes(app *config.AppConfig) http.Handler {

	mux := pat.New()

	mux.Get("/", http.HandleFunc(handlers.Repo.Home))
	mux.Get("/about", http.HandleFunc(handlers.Repo.About))

	return mux

}
